create definer = qa_cna@`%` trigger trg_catalog_product_bundle_selection_after_delete
    after DELETE
    on catalog_product_bundle_selection
    for each row
BEGIN
INSERT IGNORE INTO `cataloginventory_stock_status_cl` (`product_id`) VALUES (OLD.`parent_product_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (OLD.`parent_product_id`);

END;

