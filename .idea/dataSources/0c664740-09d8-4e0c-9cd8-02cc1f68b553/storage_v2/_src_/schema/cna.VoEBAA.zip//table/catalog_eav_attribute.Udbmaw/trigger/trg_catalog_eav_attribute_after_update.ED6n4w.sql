create definer = qa_cna@`%` trigger trg_catalog_eav_attribute_after_update
    after UPDATE
    on catalog_eav_attribute
    for each row
BEGIN
CASE (NEW.is_searchable IS NOT NULL AND NEW.is_searchable != OLD.is_searchable) OR (NEW.is_visible_in_advanced_search IS NOT NULL
                        AND
                        NEW.is_visible_in_advanced_search != OLD.is_visible_in_advanced_search) OR (NEW.is_filterable IS NOT NULL AND NEW.is_filterable != OLD.is_filterable) OR (NEW.is_filterable_in_search IS NOT NULL
                        AND
                        NEW.is_filterable_in_search != OLD.is_filterable_in_search) OR (NEW.used_for_sort_by IS NOT NULL AND NEW.used_for_sort_by != OLD.used_for_sort_by) OR (NEW.is_used_for_promo_rules IS NOT NULL
                            AND NEW.is_used_for_promo_rules != OLD.is_used_for_promo_rules) OR (NEW.used_in_product_listing IS NOT NULL
                            AND NEW.used_in_product_listing != OLD.used_in_product_listing) WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '12'); END; ELSE BEGIN END; END CASE;
END;

