create definer = qa_cna@`%` trigger trg_catalog_eav_attribute_after_delete
    after DELETE
    on catalog_eav_attribute
    for each row
BEGIN
CASE (OLD.is_searchable = 1) OR (OLD.is_visible_in_advanced_search = 1) OR (OLD.is_filterable > 0) OR (OLD.is_filterable_in_search = 1) OR (OLD.used_for_sort_by = 1) OR (OLD.is_used_for_promo_rules = 1) OR (OLD.used_in_product_listing = 1) WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '10'); END; ELSE BEGIN END; END CASE;
END;

