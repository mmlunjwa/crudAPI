create definer = qa_cna@`%` trigger trg_catalog_product_super_link_after_update
    after UPDATE
    on catalog_product_super_link
    for each row
BEGIN
INSERT IGNORE INTO `cataloginventory_stock_status_cl` (`product_id`) VALUES (NEW.`parent_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (NEW.`parent_id`);

END;

