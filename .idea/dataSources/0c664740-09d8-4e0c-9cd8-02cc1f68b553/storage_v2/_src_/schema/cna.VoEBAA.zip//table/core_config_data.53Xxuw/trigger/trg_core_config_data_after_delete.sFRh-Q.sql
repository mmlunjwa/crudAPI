create definer = qa_cna@`%` trigger trg_core_config_data_after_delete
    after DELETE
    on core_config_data
    for each row
BEGIN
CASE (OLD.path = 'catalog/price/scope') WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '13'); END; ELSE BEGIN END; END CASE;
CASE (OLD.path = 'cataloginventory/options/show_out_of_stock') OR (OLD.path = 'cataloginventory/item_options/manage_stock') WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '14'); END; ELSE BEGIN END; END CASE;
END;

