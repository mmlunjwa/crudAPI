create definer = qa_cna@`%` trigger trg_catalog_product_entity_url_key_after_insert
    after INSERT
    on catalog_product_entity_url_key
    for each row
BEGIN
INSERT IGNORE INTO `enterprise_url_rewrite_product_cl` (`entity_id`) VALUES (NEW.`entity_id`);

END;

