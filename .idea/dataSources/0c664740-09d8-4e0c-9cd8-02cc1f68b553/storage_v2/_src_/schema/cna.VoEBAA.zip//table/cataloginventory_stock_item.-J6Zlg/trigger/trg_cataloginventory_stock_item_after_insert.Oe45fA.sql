create definer = qa_cna@`%` trigger trg_cataloginventory_stock_item_after_insert
    after INSERT
    on cataloginventory_stock_item
    for each row
BEGIN
INSERT IGNORE INTO `cataloginventory_stock_status_cl` (`product_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalog_product_index_price_cl` (`entity_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (NEW.`product_id`);

END;

