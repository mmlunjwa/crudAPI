create definer = qa_cna@`%` trigger trg_core_config_data_after_insert
    after INSERT
    on core_config_data
    for each row
BEGIN
CASE (NEW.path = 'catalog/price/scope') WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '13'); END; ELSE BEGIN END; END CASE;
CASE (NEW.path = 'cataloginventory/options/show_out_of_stock') OR (NEW.path = 'cataloginventory/item_options/manage_stock') WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '14'); END; ELSE BEGIN END; END CASE;
CASE (NEW.path = 'catalog/frontend/flat_catalog_product') AND (NEW.value = 1) WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '15'); END; ELSE BEGIN END; END CASE;
CASE (NEW.path = 'catalog/frontend/flat_catalog_category') AND (NEW.value = 1) WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '16'); END; ELSE BEGIN END; END CASE;
END;

