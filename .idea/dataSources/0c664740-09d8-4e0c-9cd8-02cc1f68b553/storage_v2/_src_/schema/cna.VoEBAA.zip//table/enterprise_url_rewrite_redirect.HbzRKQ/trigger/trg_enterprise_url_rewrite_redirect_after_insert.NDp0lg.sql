create definer = qa_cna@`%` trigger trg_enterprise_url_rewrite_redirect_after_insert
    after INSERT
    on enterprise_url_rewrite_redirect
    for each row
BEGIN
INSERT IGNORE INTO `enterprise_url_rewrite_redirect_cl` (`redirect_id`) VALUES (NEW.`redirect_id`);

END;

