create definer = qa_cna@`%` trigger trg_catalog_category_entity_varchar_after_update
    after UPDATE
    on catalog_category_entity_varchar
    for each row
BEGIN
INSERT IGNORE INTO `catalog_category_flat_cl` (`entity_id`) VALUES (NEW.`entity_id`);

END;

