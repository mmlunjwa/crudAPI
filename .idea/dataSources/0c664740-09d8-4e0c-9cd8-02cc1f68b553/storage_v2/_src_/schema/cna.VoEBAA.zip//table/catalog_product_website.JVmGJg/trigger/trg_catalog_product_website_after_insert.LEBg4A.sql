create definer = qa_cna@`%` trigger trg_catalog_product_website_after_insert
    after INSERT
    on catalog_product_website
    for each row
BEGIN
INSERT IGNORE INTO `cataloginventory_stock_status_cl` (`product_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalog_category_product_index_cl` (`product_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalog_product_index_price_cl` (`entity_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalog_product_flat_cl` (`entity_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (NEW.`product_id`);

END;

