create definer = qa_cna@`%` trigger trg_catalog_product_entity_after_update
    after UPDATE
    on catalog_product_entity
    for each row
BEGIN
INSERT IGNORE INTO `catalog_product_index_price_cl` (`entity_id`) VALUES (NEW.`entity_id`);
INSERT IGNORE INTO `catalog_product_flat_cl` (`entity_id`) VALUES (NEW.`entity_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (NEW.`entity_id`);

END;

