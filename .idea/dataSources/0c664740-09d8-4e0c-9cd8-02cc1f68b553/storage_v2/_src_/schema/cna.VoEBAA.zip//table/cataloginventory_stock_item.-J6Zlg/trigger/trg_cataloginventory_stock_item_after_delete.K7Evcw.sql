create definer = qa_cna@`%` trigger trg_cataloginventory_stock_item_after_delete
    after DELETE
    on cataloginventory_stock_item
    for each row
BEGIN
INSERT IGNORE INTO `cataloginventory_stock_status_cl` (`product_id`) VALUES (OLD.`product_id`);
INSERT IGNORE INTO `catalog_product_index_price_cl` (`entity_id`) VALUES (OLD.`product_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (OLD.`product_id`);

END;

