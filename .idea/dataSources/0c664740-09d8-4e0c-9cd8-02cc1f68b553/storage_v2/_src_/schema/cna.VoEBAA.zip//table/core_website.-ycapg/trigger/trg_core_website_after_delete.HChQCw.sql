create definer = qa_cna@`%` trigger trg_core_website_after_delete
    after DELETE
    on core_website
    for each row
BEGIN
UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '7');
END;

