create definer = qa_cna@`%` trigger trg_catalog_product_link_after_insert
    after INSERT
    on catalog_product_link
    for each row
BEGIN
INSERT IGNORE INTO `cataloginventory_stock_status_cl` (`product_id`) VALUES (NEW.`product_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (NEW.`product_id`);

END;

