create definer = qa_cna@`%` trigger trg_catalog_category_entity_decimal_after_insert
    after INSERT
    on catalog_category_entity_decimal
    for each row
BEGIN
INSERT IGNORE INTO `catalog_category_flat_cl` (`entity_id`) VALUES (NEW.`entity_id`);

END;

