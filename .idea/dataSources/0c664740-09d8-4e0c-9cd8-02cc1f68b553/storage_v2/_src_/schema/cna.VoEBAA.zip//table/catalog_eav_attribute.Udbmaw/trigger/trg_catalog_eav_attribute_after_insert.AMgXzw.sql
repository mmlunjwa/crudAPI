create definer = qa_cna@`%` trigger trg_catalog_eav_attribute_after_insert
    after INSERT
    on catalog_eav_attribute
    for each row
BEGIN
CASE (NEW.is_searchable = 1) OR (NEW.is_visible_in_advanced_search = 1) OR (NEW.is_filterable > 0) OR (NEW.is_filterable_in_search = 1) OR (NEW.used_for_sort_by = 1) OR (NEW.is_used_for_promo_rules = 1) OR (NEW.used_in_product_listing = 1) WHEN TRUE THEN BEGIN UPDATE `enterprise_mview_metadata` AS `mm`
 INNER JOIN `enterprise_mview_metadata_event` AS `me` ON mm.metadata_id = me.metadata_id
SET `mm`.`status` = 2
WHERE (mview_event_id = '5'); END; ELSE BEGIN END; END CASE;
END;

