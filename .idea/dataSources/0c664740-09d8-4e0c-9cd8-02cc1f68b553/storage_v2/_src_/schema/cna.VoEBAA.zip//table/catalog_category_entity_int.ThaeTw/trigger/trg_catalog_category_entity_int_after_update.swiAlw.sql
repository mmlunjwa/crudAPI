create definer = qa_cna@`%` trigger trg_catalog_category_entity_int_after_update
    after UPDATE
    on catalog_category_entity_int
    for each row
BEGIN
INSERT IGNORE INTO `catalog_category_product_cat_cl` (`category_id`) VALUES (NEW.`entity_id`);
INSERT IGNORE INTO `catalog_category_flat_cl` (`entity_id`) VALUES (NEW.`entity_id`);

END;

