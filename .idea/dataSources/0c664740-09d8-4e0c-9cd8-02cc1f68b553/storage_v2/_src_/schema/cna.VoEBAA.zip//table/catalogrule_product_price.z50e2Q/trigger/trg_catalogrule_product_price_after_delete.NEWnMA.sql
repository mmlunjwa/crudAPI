create definer = qa_cna@`%` trigger trg_catalogrule_product_price_after_delete
    after DELETE
    on catalogrule_product_price
    for each row
BEGIN
INSERT IGNORE INTO `catalog_product_index_price_cl` (`entity_id`) VALUES (OLD.`product_id`);

END;

