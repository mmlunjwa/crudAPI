create definer = qa_cna@`%` trigger trg_catalog_product_entity_text_after_delete
    after DELETE
    on catalog_product_entity_text
    for each row
BEGIN
INSERT IGNORE INTO `catalog_product_flat_cl` (`entity_id`) VALUES (OLD.`entity_id`);
INSERT IGNORE INTO `catalogsearch_fulltext_cl` (`product_id`) VALUES (OLD.`entity_id`);

END;

