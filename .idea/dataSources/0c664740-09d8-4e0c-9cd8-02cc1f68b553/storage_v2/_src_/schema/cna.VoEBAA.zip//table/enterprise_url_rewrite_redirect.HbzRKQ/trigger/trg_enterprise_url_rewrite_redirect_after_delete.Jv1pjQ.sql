create definer = qa_cna@`%` trigger trg_enterprise_url_rewrite_redirect_after_delete
    after DELETE
    on enterprise_url_rewrite_redirect
    for each row
BEGIN
INSERT IGNORE INTO `enterprise_url_rewrite_redirect_cl` (`redirect_id`) VALUES (OLD.`redirect_id`);

END;

